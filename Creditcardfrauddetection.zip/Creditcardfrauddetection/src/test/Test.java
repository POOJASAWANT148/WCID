package test;

import java.io.File;

import com.machine.learning.decisiontrees.DecisionTree;
/**
 * 
 * @author mostafa
 * An Example of the using of decision tree
 */
public class Test {


	public static void main(String[] args) {
		
		DecisionTree tree = new DecisionTree();
		
		// Train your Decision Tree
		tree.train(new File("resources/vertebrate.psv"));
		
		// Print RootNode display xml structure from your decision tree learning
		System.out.println(tree.getRootNode());

		// Classify your new data
		System.out.println(tree
				.classify("3|e|192.168.0.108|1000|01/12/2017|11:21PM|d3|IN|chrome"));

		
	}
	
	
}
