package MianPackage;

public class CreditCardDetails {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		String CardID="";
		int attemptsforpassword=1;
		String Ipaddress="";
		double purchase_value=0;
		String signup_time="01/12/2017";
		long purchase_time=14215555;//timestamp
		String device_id="Device 1";
		String browser="chrome";
		String country="USA";
		
		
		
		
		
		
		

	}

}
