package MianPackage;

import java.sql.ResultSet;
import java.sql.SQLException;

import databaseconnection.DatabaseConnection;

public class converttoID3DB {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		DatabaseConnection con = new DatabaseConnection();
		con.dbconnection();

		String query = " select * from customer";
		
		ResultSet rs = con.getResultSet(query);
		String wholedata="";
		while(rs.next())
		{
			String partialdata="";
			
			
			for(int i=1;i<=10;i++)
			{
				
				partialdata=partialdata+rs.getString(i)+"|";
			}
				
			wholedata=wholedata+partialdata+"\n";	
		}
System.out.println(wholedata);
	}

}
