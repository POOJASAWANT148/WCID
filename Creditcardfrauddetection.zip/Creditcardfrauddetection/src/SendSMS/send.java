package SendSMS;
import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DataBase.DatabaseConnection;
import User.OTP;


/**
 * Servlet implementation class adminlogin
 */
@WebServlet("/send")
public class send extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public send() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		//String useremailid=(String)session.getAttribute("useremailid");
		
		String MobileNo =(String)request.getParameter("MobileNo");
		String Amount =(String)request.getParameter("Amount");
		int aAmount=Integer.parseInt(Amount);
		//System.out.println(imgname);
		OTP otp = new OTP();        
        String password = otp.generateOtp(4);
        session.setAttribute("OTP", password);
		session.setAttribute("Amount", Amount);
		String AccountNumber =request.getParameter("AccountNumber");
        DatabaseConnection db = new DatabaseConnection();
		db.dbconnection();
        ResultSet rs = null;
       String sql="SELECT MAX(Transaction_Amount)+1 as maxTranAmount FROM transaction WHERE AccountNo='"+AccountNumber+"';";
       rs=db.getResultSet(sql);
       System.out.println(sql);
       
       SendSms.Way2SMS(MobileNo, "Your OTP "+ password+" "+Amount);
		System.out.println(password);
       try {
				if(rs.next())
				{
					//String mobile=rs.getString("MobileNo");
					//System.out.println(MobileNo);
					String maxTranAmount = rs.getString("maxTranAmount");
					int maxtranAmount=Integer.parseInt(maxTranAmount);
					System.out.println(maxTranAmount);
					if(aAmount >= maxtranAmount){		
						response.sendRedirect("EnterOTPorQuestion.jsp");
					}else
					{
						response.sendRedirect("EnterOTP.jsp");
					}
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
