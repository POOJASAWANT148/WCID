package User;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DataBase.DatabaseConnection;

/**
 * Servlet implementation class TransacationDoneOTPandQUE
 */
@WebServlet("/TransacationDoneOTPandQUE")
public class TransacationDoneOTPandQUE extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransacationDoneOTPandQUE() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		//int Uid =(int) request.getAttribute("Uid");
		//System.out.println(Uid);
		String UserName =request.getParameter("UserName");
		//String Amount =request.getParameter("Amount");
		String AccountNumber =request.getParameter("AccountNo");
		String CardNo =request.getParameter("CardNo");
		String browser =request.getParameter("browser");
		String Answer =request.getParameter("Answer");
		String EnterAnswer =request.getParameter("EnterAnswer");
		System.out.println(EnterAnswer);
		System.out.println(Answer);
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/YYYY");
		Date date = new Date();
		String currentdate=dateFormat.format(date);
		
		
		InetAddress IP=InetAddress.getLocalHost();
		//InetAddress IPAddress=(+IP.getHostAddress());
		String IPAddress=(IP.getHostAddress());
		
		String EnterOTP = request.getParameter("OTP");
		
		String OTP=(String)session.getAttribute("OTP");
		String Amount=(String)session.getAttribute("Amount");
		//System.out.println(EnterOTP);
		
		final NetworkInterface netInf = NetworkInterface.getNetworkInterfaces().nextElement();
		final byte[] mac = netInf.getHardwareAddress();
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < mac.length; i++) {
		        sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));        
		}
		//log.info("Mac addr: {}", sb.toString());
		
		Process p = Runtime.getRuntime().exec("getmac /fo csv /nh");
	    java.io.BufferedReader in = new java.io.BufferedReader(new  java.io.InputStreamReader(p.getInputStream()));
	    String line;
	    line = in.readLine();        
	    String[] result = line.split(",");
	    String MACid=(result[0].replace('"', ' ').trim());
	    //System.out.println(MACid);
	    
	    /*String browser=request.getHeader("user-agent");
	    String browsername = "";
	    String browserversion = "";
	    String[] otherBrowsers={"Firefox","Chrome","Chrome","Safari"};
	        if(browser != null ){
	            if((browser.indexOf("MSIE") == -1) && (browser.indexOf("msie") == -1)){
	                for(int i=0; i< otherBrowsers.length;  i++){
	                    System.out.println(browser.indexOf(otherBrowsers[i]));
	                    browsername=otherBrowsers[i];
	                    break;
	                }
	                String subsString = browser.substring( browser.indexOf(browsername));
	                String Info[] = (subsString.split(" ")[0]).split("/");
	                browsername = Info[0];
	                browserversion = Info[1];
	        }
	        else{
	            String tempStr = browser.substring(browser.indexOf("MSIE"),browser.length());
	                browsername    = "IE";
	            browserversion = tempStr.substring(4,tempStr.indexOf(";"));
	        }
	    }*/
	    
	    
		if(EnterOTP.equals(OTP) && EnterAnswer.equals(Answer))
		{

		try{
		//DatabaseConnection db = new DatabaseConnection();
		//db.dbconnection();
			
			DatabaseConnection db = new DatabaseConnection();
			db.dbconnection();
			ResultSet rs1 = null;
		    String sql="SELECT * FROM userinfo WHERE UserName='"+UserName+"'";
			rs1=db.getResultSet(sql);
												
			if(rs1.next())
			{
				String aAnswer = rs1.getString("Answer");
			}	
			
		String query = "select * from addcart where UserName='"+UserName+"'";
		ResultSet rs = (ResultSet) db.getResultSet(query);
		
		while(rs.next())
		{
			
			//String username1=rs.getString("UserName");
			String id=rs.getString("id");
			//String ProductName=rs.getString("ProductName");
			//System.out.println(username1);
			
			
			//String query1 = "insert into userpurcheshproductlist(UserName,Productid,ProductName) values('"+username1+"','"+Productid+"','"+ProductName+"')";
			//db.getUpdate(query1);
			String query1 = "delete from addcart Where UserName='"+UserName+"' and id='"+id+"'";
			db.getUpdate(query1);
			
		}
		String query2 = "insert into transaction(UserName,AccountNo,CardNo,Transaction_Amount,IPaddress,MACid,BrowserName) values('"+UserName+"','"+AccountNumber+"','"+CardNo+"','"+Amount+"','"+IPAddress+"','"+MACid+"','"+browser+"')";
		db.getUpdate(query2);
		out.println("<script type=\"text/javascript\">");
    	out.println("alert('Transaction Done Successfully');");
    	out.println("location=\"products.jsp\"");
    	out.println("</script>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}else{
			out.println("<script type=\"text/javascript\">");
        	out.println("alert('wrong OTP or answer is Enter')");
        	out.println("location=\"EnterOTPorQuestion.jsp\"");
        	out.println("</script>");
			//response.sendRedirect("DownloadFile.jsp");
		}

	}

}
