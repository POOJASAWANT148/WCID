/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.security.SecureRandom;
import java.util.Random;
/**
 *
 * @author test
 */
public class OTP {

    public static String generateOtp(int PASSWORD_LENGTH)
	  {
	      Random RANDOM = new SecureRandom();
	      String letters = "ABCDEFGHJKMNPQRSTUVWXYZ0123456789";

	      String pw = "";
	      for (int i=0; i<PASSWORD_LENGTH; i++)
	      {
	          int index = (int)(RANDOM.nextDouble()*letters.length());
	          pw += letters.substring(index, index+1);
	      }
	      return pw;              
	  }
            public static void main(String[] args) 
    {
        OTP otp = new OTP();
        @SuppressWarnings("static-access")
        String password = otp.generateOtp(10);
        System.out.println(password);
    }
}