package User;

import java.io.File;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DataBase.DatabaseConnection;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String FirstName=request.getParameter("FirstName");
		String LastName=request.getParameter("LastName");
		String Address=request.getParameter("Address");
		String City=request.getParameter("City");
		String State=request.getParameter("State");
		String Country=request.getParameter("Country");
		String Pincode=request.getParameter("Pincode");
		String MobileNumber=request.getParameter("MobileNumber");
		String Email=request.getParameter("Email");
		String DOB=request.getParameter("DOB");
		String gender=request.getParameter("gender");
		String AccountNo=request.getParameter("AccountNo");
		String CardNo=request.getParameter("CardNo");
		String UserName=LastName+FirstName;
		String Password=request.getParameter("Password");
		String SecurityQuestion=request.getParameter("SecurityQuestion");
		String Answer=request.getParameter("Answer");
		
		
		DatabaseConnection db = new DatabaseConnection();
		db.dbconnection();
		String query = "insert into userinfo(FirstName,LastName,Address,City,State,Country,Pincode,MobileNumber,Email,DOB,gender,AccountNo,CardNo,UserName,Password,SecurityQuestion,Answer) values('"+FirstName+"','"+LastName+"','"+Address+"','"+City+"','"+State+"','"+Country+"','"+Pincode+"','"+MobileNumber+"','"+Email+"','"+DOB+"','"+gender+"','"+AccountNo+"','"+CardNo+"','"+UserName+"','"+Password+"','"+SecurityQuestion+"','"+Answer+"')";
		db.getUpdate(query);
		
		
		
		out.println("<script type=\"text/javascript\">");
    	out.println("alert('New User Add Successfully and user id is "+UserName+"');");
    	out.println("location=\"login.jsp\"");
    	out.println("</script>");
	}

}
