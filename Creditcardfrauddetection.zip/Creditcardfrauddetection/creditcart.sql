/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.5.5-10.1.16-MariaDB : Database - newcreditcard
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`newcreditcard` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `newcreditcard`;

/*Table structure for table `addcart` */

DROP TABLE IF EXISTS `addcart`;

CREATE TABLE `addcart` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(20) DEFAULT NULL,
  `UserName` varchar(200) DEFAULT NULL,
  `ProductName` varchar(200) DEFAULT NULL,
  `ProductPrice` varchar(200) DEFAULT NULL,
  `Quantity` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `addcart` */

insert  into `addcart`(`id`,`UserID`,`UserName`,`ProductName`,`ProductPrice`,`Quantity`) values (1,'2','madhavisubhash','V3Squared Men Cotton T-Shirt','399','1'),(2,'3','krahul','V3Squared Men Cotton T-Shirt','499','1');

/*Table structure for table `admindetail` */

DROP TABLE IF EXISTS `admindetail`;

CREATE TABLE `admindetail` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `AdminName` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admindetail` */

insert  into `admindetail`(`id`,`AdminName`,`Password`) values (1,'a','a');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cname` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`id`,`cname`) values (1,'Men\'s Wear'),(2,'Women\'s Wear'),(3,'Kid\'s Wear'),(4,'Home Collection'),(5,'Office Collection'),(6,'Decorations');

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `pcate` varchar(500) NOT NULL,
  `pscate` varchar(255) NOT NULL,
  `pname` varchar(500) NOT NULL,
  `pprice` varchar(500) NOT NULL,
  `pqty` varchar(500) NOT NULL,
  `pstock` varchar(500) NOT NULL,
  `image1` varchar(500) NOT NULL,
  `image2` varchar(500) NOT NULL,
  `image3` varchar(500) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `products` */

insert  into `products`(`id`,`pcate`,`pscate`,`pname`,`pprice`,`pqty`,`pstock`,`image1`,`image2`,`image3`,`description`) values (10,'1','1','V3Squared Men Cotton T-Shirt','399','1','800','2.jpg','22.jpg','222.jpg','Material: Cotton Fit: Regular Fit Wash Care: Do Not Iron on Print, Dry in Shade, Do Not Bleach, Machine Wash Warm at 40°C'),(11,'1','1','V3Squared Men Cotton T-Shirt','499','1','800','11.jpg','111.jpg','11111.jpg','Material: Cotton Fit: Regular Fit Wash Care: Do Not Iron on Print, Dry in Shade, Do Not Bleach, Machine Wash Warm at 40°C');

/*Table structure for table `subcat` */

DROP TABLE IF EXISTS `subcat`;

CREATE TABLE `subcat` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `subname` varchar(255) NOT NULL,
  `cat` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

/*Data for the table `subcat` */

insert  into `subcat`(`id`,`subname`,`cat`) values (1,'Clothing','1'),(2,'Wallets','1'),(3,'Shoes','1'),(4,'Watches','1'),(5,'Accessories','1'),(6,'Clothing','2'),(7,'Wallets,Bags','2'),(8,'Footwear','2'),(9,'Watches','2'),(10,'Accessories','2'),(11,'Jewellery','2'),(12,'Beauty & Grooming','2'),(13,'Kids Home Fashion','3'),(14,'Boy\'s Clothing','3'),(15,'Girl\'s Clothing','3'),(16,'Shoes','3'),(17,'Brand Stores','3'),(18,'Cookware','4'),(19,'Sofas','4'),(20,'Dining Tables','4'),(21,'Shoe Racks','4'),(22,'Home Decor','4'),(23,'Carpets','5'),(24,'Tables','5'),(25,'Sofas','5'),(26,'Shoe Racks','5'),(27,'Sockets','5'),(28,'Electrical Machines','5'),(29,'Toys','6'),(30,'Wall Clock','6'),(31,'Lighting','6'),(32,'Top Brands','6');

/*Table structure for table `transaction` */

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `Tid` int(200) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(200) DEFAULT NULL,
  `AccountNo` varchar(200) DEFAULT NULL,
  `CardNo` varchar(200) DEFAULT NULL,
  `Transaction_Amount` varchar(200) DEFAULT NULL,
  `TransactionTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `IPaddress` varchar(200) DEFAULT NULL,
  `MACid` varchar(200) DEFAULT NULL,
  `BrowserName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Tid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `transaction` */

insert  into `transaction`(`Tid`,`UserName`,`AccountNo`,`CardNo`,`Transaction_Amount`,`TransactionTime`,`IPaddress`,`MACid`,`BrowserName`) values (3,'madhavisubhash','1234567890123','123456','998','2017-12-19 17:25:48','192.168.0.104','54-04-A6-62-A8-FD','Chrome'),(5,'madhavisubhash','1234567890123','123456','399','2017-12-20 11:16:15','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(6,'madhavisubhash','1234567890123','123456','798','2017-12-20 12:15:28','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(7,'madhavisubhash','1234567890123','123456','399','2017-12-20 12:38:58','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(8,'madhavisubhash','1234567890123','123456','499','2017-12-20 12:48:07','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(9,'madhavisubhash','1234567890123','123456','499','2017-12-20 16:47:23','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(10,'madhavisubhash','1234567890123','123456','399','2017-12-20 16:54:57','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(11,'krahul','123456789012345','456321','399','2017-12-20 17:48:03','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(12,'madhavisubhash','1234567890123','123456','399','2017-12-20 17:53:22','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(13,'madhavisubhash','1234567890123','123456','399','2017-12-20 17:58:03','192.168.0.101','54-04-A6-62-A8-FD','Chrome'),(15,'krahul','123456789012345','456321','399','2017-12-20 18:02:14','192.168.0.101','54-04-A6-62-A8-FD','IE');

/*Table structure for table `userinfo` */

DROP TABLE IF EXISTS `userinfo`;

CREATE TABLE `userinfo` (
  `Uid` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(25) DEFAULT NULL,
  `LastName` varchar(25) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `State` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Pincode` int(11) DEFAULT NULL,
  `MobileNumber` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `DOB` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `AccountNo` varchar(100) DEFAULT NULL,
  `CardNo` varchar(16) DEFAULT NULL,
  `UserName` varchar(500) DEFAULT NULL,
  `Password` varchar(40) DEFAULT NULL,
  `SecurityQuestion` varchar(500) DEFAULT NULL,
  `Answer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `userinfo` */

insert  into `userinfo`(`Uid`,`FirstName`,`LastName`,`Address`,`City`,`State`,`Country`,`Pincode`,`MobileNumber`,`Email`,`DOB`,`gender`,`AccountNo`,`CardNo`,`UserName`,`Password`,`SecurityQuestion`,`Answer`) values (2,'subhash','madhavi','ghatkoper','mumbai','maharastra','India',800074,'9637151412','madhavisubhash9@gmail.com','05 octomber 1984','Male','1234567890123','123456','madhavisubhash','s','father name','narayan'),(3,'rahul','k','airoli','mumbai','maharastra','India',800074,'9635452172','rahul@gmail.com','05 nov 1995','Male','123456789012345','456321','krahul','r','father name','mk');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
