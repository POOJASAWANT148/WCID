package com.wcd.dao;

import java.util.List;

import com.wcd.model.UserRegister;

public interface InterfaceUserRegister {
	public void addUser(UserRegister user);
	public List<UserRegister> listUser();//retrieve/listAll
}
