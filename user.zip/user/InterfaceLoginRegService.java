package com.wcd.service;

import java.util.List;

import com.wcd.model.UserRegister;



public interface InterfaceLoginRegService {
	public void addUser(UserRegister user);
	public List<UserRegister> listUser();//retrieve/listAll
}
