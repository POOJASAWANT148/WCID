package com.wcd.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcd.dao.InterfaceUserRegister;
import com.wcd.model.UserRegister;
@Service
public class LoginRegisterService implements InterfaceLoginRegService {
private InterfaceUserRegister interfaceUserR;


@Autowired

public void setInterfaceUserR(InterfaceUserRegister interfaceUserR) {
	this.interfaceUserR = interfaceUserR;
}

	@Override
	@Transactional
	public void addUser(UserRegister user) {
	this.interfaceUserR.addUser(user);
		
	}

	@Override
	public List<UserRegister> listUser() {
		
		return null;
	}

}
