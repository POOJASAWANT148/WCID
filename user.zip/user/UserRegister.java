package com.wcd.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="userLogin")
public class UserRegister  implements Serializable{
	@javax.persistence.Id
	@Column(name="UserId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer userId;
	@Column(name="name")
	private String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Column(name="email")
	private String email;
	
	@Column(name="password")
	private String password;
	private Integer phoneNumber;

	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserRegister(Integer userId, String email, String username, String password) {
		super();
		this.userId = userId;
		this.email = email;
		this.username=username;
		this.password = password;
	}
	public UserRegister() {
		super();
	}
	@Override
	public String toString() {
		return "UserRegister [userId=" + userId + ", email=" + email + ", username=" + username + ", password="
				+ password + "]";
	}
	
}
