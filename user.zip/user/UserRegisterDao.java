package com.wcd.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.wcd.model.UserRegister;
@Repository
public class UserRegisterDao implements InterfaceUserRegister{
	private static final Logger logger = LoggerFactory.getLogger(UserRegisterDao.class);

	private SessionFactory sessionFactory;
	private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	@Override
	public void addUser(UserRegister user) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		session.persist(user);
		logger.info("UserDetails are saved successfully, User Registration="+user);
		tx.commit();
		session.close();
		
	}

	@Override
	public List<UserRegister> listUser() {

		return null;
	}

}
