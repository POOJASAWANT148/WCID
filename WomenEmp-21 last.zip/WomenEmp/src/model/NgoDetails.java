package model;

import java.sql.Blob;
import java.sql.Date;
import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="NgoDetails")
public class NgoDetails {
	@Id
	@Column(name="detailId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer detailId;
	@Column
	private String orgName;
	@Column
	private String address;
	@Column
	private String achievements;
	@Column
	private String uuid;
	@Column
	private Date dateOfReg;
	@Column
	private String projectInCharge;
	@Column
	private String position;
	@Column
	private String email;
	@Column
	private String MobileNo;
	//private Blob regCerti;
	@Column
	private int noOfStaff;
	
	@ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                CascadeType.PERSIST,
                CascadeType.MERGE
            })
    @JoinTable(name = "ngo_course",
            joinColumns = { @JoinColumn(name = "detailId") },
            inverseJoinColumns = { @JoinColumn(name = "courseId") })
	  private List<Course>courseList=new ArrayList<Course>();
	 
	@Column
	private String status;

	/*
	 * public List<Course> getCourseList() { return courseList; } public void
	 * setCourseList(List<Course> courseList) { this.courseList = courseList; }
	 */
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getDetailId() {
		return detailId;
	}
	public void setDetailId(Integer detailId) {
		this.detailId = detailId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getAchievements() {
		return achievements;
	}
	public void setAchievements(String achievements) {
		this.achievements = achievements;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Date getDateOfReg() {
		return dateOfReg;
	}
	public void setDateOfReg(Date dateOfReg) {
		this.dateOfReg = dateOfReg;
	}
	public String getProjectInCharge() {
		return projectInCharge;
	}
	public void setProjectInCharge(String projectInCharge) {
		this.projectInCharge = projectInCharge;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}

	/*
	 * public Blob getRegCerti() { return regCerti; } public void setRegCerti(Blob
	 * regCerti) { this.regCerti = regCerti; }
	 */
	public int getNoOfStaff() {
		return noOfStaff;
	}
	public void setNoOfStaff(int noOfStaff) {
		this.noOfStaff = noOfStaff;
	}
	public NgoDetails(Integer detailId, String orgName, String address, String achievements, String uuid,
			Date dateOfReg, String projectInCharge, String position, String email, String mobileNo, /* Blob regCerti, */
			int noOfStaff,/* List<Course> courseList, */String status) {
		super();
		this.detailId = detailId;
		this.orgName = orgName;
		this.address = address;
		
		this.achievements = achievements;
		this.uuid = uuid;
		this.dateOfReg = dateOfReg;
		this.projectInCharge = projectInCharge;
		this.position = position;
		this.email = email;
		MobileNo = mobileNo;
		//this.regCerti = regCerti;
		this.noOfStaff = noOfStaff;
		//this.courseList = courseList;
		this.status = status;
	}
	public NgoDetails() {
		super();
	}
	@Override
	public String toString() {
		return "NgoDetails [detailId=" + detailId + ", orgName=" + orgName + ", address=" + address + ", achievements=" + achievements + ", uuid=" + uuid + ", dateOfReg=" + dateOfReg
				+ ", projectInCharge=" + projectInCharge + ", position=" + position + ", email=" + email + ", MobileNo="
				+ MobileNo + ", noOfStaff=" + noOfStaff + ", status=" + status + "]";
	}
	
	//, courseList=" + courseList+", regCerti=" + regCerti + " 
	
	
}
