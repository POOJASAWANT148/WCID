package com.wcd.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.wcd.service.IUserReg;

import model.Course;
import model.NgoDetails;
import model.UserRegistration;
@Repository
public interface IUserRegDao {
	
	public void addUserReg(UserRegistration userReg);
	public void updateUserReg(UserRegistration userReg);//update/modify
	public List<UserRegistration> listUserReg();//retrieve/listAll
	public UserRegistration getUserRegById(int id);//search
	public void removeUserReg(int id);//delete/remove
	public void acceptUserReg(int id);

	public List<UserRegistration> listUserByRegId(Integer userRegId);
	public void attendUserReg(int id);
}
