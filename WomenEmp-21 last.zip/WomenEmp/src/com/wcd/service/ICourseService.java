package com.wcd.service;

import java.util.List;

import org.springframework.stereotype.Service;

import model.Course;

@Service
public interface ICourseService {
	public void addCourseDet(Course n);//insert
	public void updateCourseDet(Course p);//update/modify
	public List<Course> listCourseDetail();//retrieve/listAll
	public Course getCourseById(int id);//search
	public void removeCourse(int id);//delete/remove
	public List<Course> listCourseByCAO(String ngoName, String courseName);
}
