package com.wcd.dao;


import org.springframework.stereotype.Repository;

import model.User;
@Repository
public interface IUserDao {
	public void addUser(User n);//insert
	public boolean verifyUser(String email,String password);
		public User getUserDetails(int userDetailsId);
		public User returnUser(User n);
}
