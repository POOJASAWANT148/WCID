package com.wcd.dao;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



import model.Ngo;
@Repository
public class NgoDaoImpl implements INgoDao,Serializable{
	private static final Logger logger = 			
			LoggerFactory.getLogger(NgoDaoImpl.class);
	private SessionFactory sessionFactory;
private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
	}
	
	
	
	@Override
	@Transactional
	public void addNgo(Ngo n) {
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		session.persist(n);
		logger.info("Ngo saved successfully, Ngo Details="
		+ n);
		tx.commit();
		session.close();
	}
	@Override
	@Transactional
	public Ngo getNgoDetails(int ngoDetailsId) {
		
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		System.out.println("Inside getEmployeeDetails2");
		Ngo p = (Ngo) session.load(Ngo.class, new Integer(ngoDetailsId));
		logger.info("Ngo loaded successfully, Person details=" + p);
		tx.commit();
		session.close();
		return p;
		
	}



	@Override
	public boolean verifyUser(String uuid, String password) {
		Session session = this.sessionFactory.openSession();
		   System.out.println("dao");
		  String query="from Ngo where uuid=:uuid and password=:password";
		  System.out.println("query");
		  Query q=session.createQuery(query);
		  q.setString("uuid", uuid);
		  q.setString("password", password);
		  List<Ngo> l=q.list();  
if(l.size()==0)
{
	  return false;
}
session.close();
	  return true;
	}



	@Override
	public Ngo returnNgo(Ngo n) {
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		 String uuid=n.getUuid();
		 String password=n.getPassword();
		  String query="from Ngo where uuid=:uuid and password=:password";
		  Query q=session.createQuery(query);
		  q.setString("uuid", uuid);
		  q.setString("password", password);
		  List <Ngo> ngoList=q.list();
		  Iterator<Ngo> ngoItr=ngoList.iterator();
		  Ngo n1=new Ngo();
		  while(ngoItr.hasNext())
		  {
			  n1=(Ngo)ngoItr.next();
		  }
		return n1;
	}
	
	
}


	
	

